package com;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class addbooks extends GenericServlet
{
	Connection con;

          public void init(ServletConfig sc)
          {
           try
           {
            super.init(sc);
            Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/wad_project","root" ,"Jack" );
           }
           catch(Exception e){e.printStackTrace();}
          }

          public void service1(ServletRequest req,ServletResponse res)
          {
           try
           {
            Statement st = con.createStatement();
            String str1 = req.getParameter("book");
            String str2 = req.getParameter("bc");
            String str3 = req.getParameter("aut");
            String str4 = req.getParameter("doa");
            String str5 = req.getParameter("pr");
            String str6 = req.getParameter("rn");
            String str7 = req.getParameter("nob");
            String str8 = req.getParameter("sc");
            ServletOutputStream sos = res.getOutputStream();
            int k = st.executeUpdate("insert into addbooks values('"+str1+"','"+str2+"','"+str3+"','"+str4+"','"+str5+"','"+str6+"','"+str7+"','"+str8+"')"); 
            if(k>0)
             sos.println("books are added successfully");
            else
             sos.println("books are not added");
           }
           catch(Exception ex){ex.printStackTrace();}
          }

		@Override
		public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
			// TODO Auto-generated method stub
			
		}
}

