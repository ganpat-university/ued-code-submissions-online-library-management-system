package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns="/addmembers")
public class addmembers extends HttpServlet{
public void init() {}
public void doGet(HttpServletRequest req, HttpServletResponse
resp) throws IOException {
Connection con;
try {
con =DriverManager.getConnection("jdbc:mysql://localhost:3309/wad_project","root","root");
resp.setContentType("text/html");
PrintWriter out = resp.getWriter();
String Id_No = req.getParameter("ID_No");
String Name= req.getParameter("Name");
String Address = req.getParameter("Address");
//String Date_Of_Issue = req.getParameter("Date_Of_Issue");
//String Date_Of_Expiry= req.getParameter("Date_Of_Expiry");
//String Status_Of_MS= req.getParameter("Status_Of_MS");
//String Type_Of_Status= req.getParameter("Type_Of_Status");
//String Amount=req.getParameter("Amount");
String Password= req.getParameter("Password");
String query = "insert into members values("+"'"+Id_No+"',"+"'"+Name+"',"+"'"+Address+"',"+"'"+Password+"'"+")";
Statement st = con.createStatement();
st.executeUpdate(query);
st.close();
con.close();
out.println("<h1>"+"Data Added To database Succesfully"+"</h1>");
} catch (SQLException e) {
PrintWriter out1 = resp.getWriter();
out1.println(e);
}
}
public void destroy() {}
}